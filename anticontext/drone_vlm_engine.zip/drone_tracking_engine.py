"""
drone_tracking_engine.py
==========================
Full pipeline — Phase 1-6 integrated:

  camera → YOLOv8n detection
         → SmolObjectClassifier  (small / uncertain boxes get VLM labels)
         → Kalman tracker  (predict / update every frame)
         → periodic SmolVLM re-ID check  (every REID_INTERVAL_SEC)
         → decision layer  (stopped / course-changed / lost)
         → DroneController command  (move_toward / hold_position / search_pattern / scan / rtl)
         ← UDP command receiver  (port 5000 — voice_command_interface.py sends here)

Controls (keyboard):
  q  — quit
  l  — lock onto the nearest high-confidence detection
  h  — hold / hover immediately
  s  — trigger search pattern
  r  — return to launch (sim: fly to centre)

pip install: ultralytics opencv-python transformers torch pillow pygame numpy
Run:
    python drone_tracking_engine.py
"""

import argparse
import concurrent.futures
import json
import queue
import socket
import threading
import time

import cv2
import numpy as np
from ultralytics import YOLO

from drone_controller import Sim2DDroneController
from kalman_tracker import KalmanTrack
from reid_engine import ReIDEngine
from small_object_classifier import SmolObjectClassifier


# ============================================================
# CONFIGURATION
# ============================================================

YOLO_MODEL_PATH          = "../yolov8n.pt"   # <-- CHANGE DETECTOR MODEL
TARGET_CLASS_NAME        = "person"          # <-- CHANGE TARGET CLASS (COCO label)
DETECTION_CONFIDENCE     = 0.4              # <-- CHANGE detection threshold

CAMERA_INDEX             = 0
FRAME_WIDTH              = 640
FRAME_HEIGHT             = 480

MAX_MISSED_FRAMES        = 15              # <-- frames before "target lost"
REACQUIRE_SEARCH_RADIUS  = 150            # <-- px radius for re-matching after miss

# UDP command receiver (matches voice_command_interface.py sender)
CMD_UDP_HOST             = "0.0.0.0"
CMD_UDP_PORT             = 5000

# Scan waypoints for 'scan' / 'survey' mission commands (pixel coords in sim)
DEFAULT_SCAN_WAYPOINTS   = [
    (160, 120), (480, 120), (480, 360), (160, 360),  # rectangle survey pattern
]


# ============================================================
# CAMERA SELECTION
# ============================================================

def select_camera():
    """
    Prompt user or parse CLI args to select camera source:
      - Laptop / built-in webcam (index 0 or integer)
      - IP Webcam URL (e.g. http://192.168.0.253:8080/video)
    """
    parser = argparse.ArgumentParser(description="Drone Tracking Engine")
    parser.add_argument("--cam", "--camera", type=str, default=None, help="Camera index (e.g. 0) or IP URL (e.g. http://192.168.0.253:8080/video)")
    args, _ = parser.parse_known_args()

    cam_source = args.cam
    if cam_source is None:
        print("\n" + "=" * 54)
        print(" SELECT CAMERA SOURCE")
        print("=" * 54)
        print("  [1] Laptop / Built-in Webcam (Index 0)")
        print("  [2] IP Webcam (Phone App / Network Camera)")
        print("=" * 54)
        try:
            choice = input("Select option (1 or 2, default 1): ").strip()
        except (KeyboardInterrupt, EOFError):
            choice = "1"

        if choice == "2":
            default_url = "http://192.168.0.253:8080/video"
            print("\nIP Webcam Setup (e.g. Android IP Webcam App):")
            try:
                url_input = input(f"Enter IP Webcam URL [Press Enter for {default_url}]: ").strip()
            except (KeyboardInterrupt, EOFError):
                url_input = ""
            cam_source = url_input if url_input else default_url
        else:
            cam_source = 0

    if isinstance(cam_source, str):
        if cam_source.isdigit():
            cam_source = int(cam_source)
        else:
            if not (cam_source.startswith("http://") or cam_source.startswith("https://") or cam_source.startswith("rtsp://")):
                cam_source = f"http://{cam_source}"
            if not any(cam_source.endswith(ext) for ext in ["/video", ".mjpg", ".mp4", "/shot.jpg", "/mjpeg"]):
                cam_source = cam_source.rstrip("/") + "/video"

    return cam_source


# ============================================================
# THREADED CAMERA STREAM (Zero-Lag IP Webcam & USB Camera)
# ============================================================

class ThreadedCameraStream:
    """
    Background thread that continuously grabs frames from an IP camera / webcam stream.
    Eliminates network buffer queue lag by always serving the LATEST available frame
    and automatically resizing high-resolution phone streams (1080p/4K) to 640x480.
    """
    def __init__(self, src, target_size=(FRAME_WIDTH, FRAME_HEIGHT)):
        self.src = src
        self.target_size = target_size
        self.cap = cv2.VideoCapture(src)
        
        if isinstance(src, int):
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, target_size[0])
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, target_size[1])
        
        # Buffer size setting (attempt to set to 1 for FFmpeg)
        self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

        self.latest_frame = None
        self.grabbed = False
        self.stopped = False
        self.lock = threading.Lock()

        if self.cap.isOpened():
            self.grabbed, frame = self.cap.read()
            if self.grabbed and frame is not None:
                if (frame.shape[1], frame.shape[0]) != target_size:
                    frame = cv2.resize(frame, target_size)
                self.latest_frame = frame
            
            self.thread = threading.Thread(target=self._update_loop, daemon=True)
            self.thread.start()

    def _update_loop(self):
        while not self.stopped:
            if not self.cap.isOpened():
                time.sleep(0.01)
                continue
            
            grabbed, frame = self.cap.read()
            if grabbed and frame is not None and frame.size > 0:
                if (frame.shape[1], frame.shape[0]) != self.target_size:
                    frame = cv2.resize(frame, self.target_size)
                
                with self.lock:
                    self.latest_frame = frame
                    self.grabbed = grabbed
            else:
                time.sleep(0.01)

    def read(self):
        with self.lock:
            if self.latest_frame is None:
                return False, None
            return self.grabbed, self.latest_frame.copy()

    def isOpened(self):
        return self.cap.isOpened()

    def release(self):
        self.stopped = True
        if self.cap.isOpened():
            self.cap.release()


# ============================================================
# HELPERS
# ============================================================

def detect_target_candidates(yolo_model, frame, target_class_name, conf_threshold):
    """
    Run YOLOv8n on the frame.
    Returns list of dicts: {bbox, conf, center, yolo_label, vlm_label (may be None)}
    """
    results = yolo_model.predict(source=frame, verbose=False, conf=conf_threshold)
    r = results[0]
    candidates = []
    if r.boxes is None:
        return candidates

    names = yolo_model.model.names
    for box in r.boxes:
        cls_id   = int(box.cls[0])
        label    = names.get(cls_id, str(cls_id))
        if label != target_class_name:
            continue
        x1, y1, x2, y2 = box.xyxy[0].tolist()
        conf     = float(box.conf[0])
        center   = ((x1 + x2) / 2, (y1 + y2) / 2)
        candidates.append({
            "bbox":       (x1, y1, x2, y2),
            "conf":       conf,
            "center":     center,
            "yolo_label": label,
            "vlm_label":  None,    # filled in by SmolObjectClassifier if triggered
        })
    return candidates


def pick_best_candidate(candidates, predicted_xy, max_dist_px):
    """Closest detection to the Kalman-predicted position, within range."""
    best, best_dist = None, max_dist_px
    for c in candidates:
        dist = ((c["center"][0] - predicted_xy[0]) ** 2 +
                (c["center"][1] - predicted_xy[1]) ** 2) ** 0.5
        if dist < best_dist:
            best_dist, best = dist, c
    return best


def crop_bbox(frame, bbox, pad=10):
    h, w = frame.shape[:2]
    x1, y1, x2, y2 = [int(v) for v in bbox]
    x1, y1 = max(0, x1 - pad), max(0, y1 - pad)
    x2, y2 = min(w, x2 + pad), min(h, y2 + pad)
    return frame[y1:y2, x1:x2]


# ============================================================
# UDP COMMAND RECEIVER
# Runs in background thread; pushes parsed command dicts to a queue.Queue
# ============================================================

class CommandReceiver:
    """
    Binds a UDP socket on CMD_UDP_PORT and deserialises incoming JSON
    command packets (sent by voice_command_interface.py).

    Commands arrive as:
        {"action": "follow", "target": "red jacket", "params": {}}
    """

    def __init__(self, host=CMD_UDP_HOST, port=CMD_UDP_PORT):
        self.queue: queue.Queue = queue.Queue(maxsize=16)
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.settimeout(0.5)
        self._sock.bind((host, port))
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        print(f"[CmdReceiver] Listening for voice commands on UDP {host}:{port}")

    def _loop(self):
        while True:
            try:
                data, _ = self._sock.recvfrom(4096)
                cmd = json.loads(data.decode("utf-8"))
                print(f"[CmdReceiver] Received command: {cmd}")
                if not self.queue.full():
                    self.queue.put(cmd)
            except socket.timeout:
                continue
            except Exception as exc:
                print(f"[CmdReceiver] Error: {exc}")


# ============================================================
# MISSION STATE
# ============================================================

MISSION_FOLLOW  = "follow"
MISSION_HOVER   = "hover"
MISSION_SEARCH  = "search"
MISSION_SCAN    = "scan"
MISSION_RTL     = "rtl"


# ============================================================
# MAIN ENGINE
# ============================================================

def main():
    cam_source = select_camera()

    print("=" * 62)
    print(" Drone Tracking Engine — Phase 1-6")
    print(" YOLOv8n + Kalman + SmolVLM re-ID + Voice Commands")
    print("=" * 62)
    print(" Keys: [q] quit  [l] lock target  [u] unlock target  [h] hover  [s] search  [r] RTL")
    print("=" * 62)

    # --- Load SmolVLM ONCE; share across reid + small-object classifier ---
    print("[ENGINE] Loading SmolVLM-256M-Instruct (shared model) ...")
    import torch
    from transformers import AutoProcessor

    try:
        from transformers import AutoModelForImageTextToText as AutoVLMModel
    except ImportError:
        from transformers import AutoModelForVision2Seq as AutoVLMModel

    device    = "cuda" if torch.cuda.is_available() else "cpu"
    processor = AutoProcessor.from_pretrained("HuggingFaceTB/SmolVLM-256M-Instruct")
    vlm_model = AutoVLMModel.from_pretrained(
        "HuggingFaceTB/SmolVLM-256M-Instruct", torch_dtype=torch.float32
    ).to(device)
    vlm_model.eval()
    print(f"[ENGINE] SmolVLM loaded on {device}. Sharing with ReID + Classifier.")

    # --- Subsystems ---
    yolo_model  = YOLO(YOLO_MODEL_PATH)
    reid        = ReIDEngine(shared_model=vlm_model, shared_processor=processor)
    classifier  = SmolObjectClassifier(shared_model=vlm_model, shared_processor=processor)
    drone       = Sim2DDroneController(world_size=(FRAME_WIDTH, FRAME_HEIGHT))
    cmd_recv    = CommandReceiver()

    # --- Camera ---
    print(f"[ENGINE] Connecting to camera source: {cam_source} (Threaded Zero-Lag Stream)...")
    cap = ThreadedCameraStream(cam_source, target_size=(FRAME_WIDTH, FRAME_HEIGHT))

    if not cap.isOpened():
        print(f"[ERROR] Could not open camera source: {cam_source}")
        print("Please check your camera index or IP network connection.")
        return

    tracker       = None
    locked        = False
    mission_state = MISSION_SEARCH   # start in search until target is locked
    status_text   = "No target — press 'l' to lock"
    reid_status   = ""
    frame_count   = 0
    current_target_class = TARGET_CLASS_NAME

    # Async VLM workers & state
    vlm_executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
    classification_future = None
    reid_future = None
    vlm_spatial_cache = []  # list of {"center": (cx, cy), "label": str, "time": float}



    while True:
        ret, frame = cap.read()
        if not ret:
            print("[ERROR] Failed to read frame.")
            break
        frame_count += 1

        # ---- 1. Process any queued voice/text commands ----
        while not cmd_recv.queue.empty():
            cmd = cmd_recv.queue.get_nowait()
            action = cmd.get("action", "hover")
            target_desc = cmd.get("target")
            coco_class = cmd.get("coco_class")

            if action in ("hover", "stop"):
                mission_state = MISSION_HOVER
                drone.hold_position()
                status_text = f"[CMD] Hovering (voice: '{action}')"

            elif action in ("follow", "track"):
                mission_state = MISSION_FOLLOW
                if coco_class:
                    current_target_class = coco_class

                if target_desc:
                    # Update the re-ID target tag to what the voice described
                    reid.target_tag = target_desc.lower()
                    status_text = f"[CMD] Following {current_target_class}: '{target_desc}'"
                else:
                    status_text = f"[CMD] Following {current_target_class} (re-lock on next detection)"

            elif action == "search":
                mission_state = MISSION_SEARCH
                drone.search_pattern()
                locked = False
                status_text = "[CMD] Searching for target"

            elif action in ("scan", "survey"):
                mission_state = MISSION_SCAN
                drone.scan_waypoints(DEFAULT_SCAN_WAYPOINTS)
                status_text = f"[CMD] Scanning waypoints ({action})"

            elif action in ("rtl", "return", "land"):
                mission_state = MISSION_RTL
                drone.return_to_launch()
                status_text = "[CMD] Returning to launch"

            print(f"[ENGINE] Mission → {mission_state}  |  {status_text}")

        # ---- 2. YOLO detection ----
        candidates = detect_target_candidates(
            yolo_model, frame, current_target_class, DETECTION_CONFIDENCE
        )

        # ---- 3. Async SmolObjectClassifier & ReID Results ----
        now = time.time()
        # Reap finished classification
        if classification_future and classification_future.done():
            try:
                res = classification_future.result()
                if res and res["label"] and res["label"] != "too small to classify":
                    vlm_spatial_cache.append(res)
            except Exception as e:
                print(f"[VLM Worker] Error: {e}")
            classification_future = None

        # Reap finished ReID
        if reid_future and reid_future.done():
            try:
                res = reid_future.result()
                if isinstance(res, tuple):
                    is_match, similarity, candidate_tag = res
                    if not is_match:
                        reid_status = f"⚠ ID switch? sim={similarity:.2f}"
                    else:
                        reid_status = f"✓ Re-ID match sim={similarity:.2f}"
                elif isinstance(res, str):
                    reid.target_tag = res
                    print(f"[ENGINE] Re-ID target tag locked in background: '{res}'")
            except Exception as e:
                print(f"[ReID Worker] Error: {e}")
            reid_future = None

        # Apply spatial cache and trigger new classifications
        vlm_spatial_cache = [entry for entry in vlm_spatial_cache if now - entry["time"] < 4.0]
        for c in candidates:
            cx, cy = c["center"]
            c["vlm_label"] = None
            # Check spatial cache (within ~50px)
            for entry in vlm_spatial_cache:
                if (cx - entry["center"][0])**2 + (cy - entry["center"][1])**2 < 2500:
                    c["vlm_label"] = entry["label"]
                    break

            # If no label, detection is small/shaky, and thread is free -> submit job
            if not c["vlm_label"]:
                area = (c["bbox"][2] - c["bbox"][0]) * (c["bbox"][3] - c["bbox"][1])
                if (area < 4096 or c["conf"] < 0.55) and classification_future is None:
                    crop = crop_bbox(frame, c["bbox"]).copy()
                    def _classify_task(img, center):
                        return {"label": classifier.classify(img), "center": center, "time": time.time()}
                    classification_future = vlm_executor.submit(_classify_task, crop, c["center"])

        # Auto-lock target when in MISSION_FOLLOW if not locked yet
        if mission_state == MISSION_FOLLOW and (not locked or tracker is None) and candidates:
            best = max(candidates, key=lambda c: c["conf"])
            tracker = KalmanTrack(initial_xy=best["center"], dt=1 / 15.0)
            crop = crop_bbox(frame, best["bbox"])
            if crop.size > 0:
                if best.get("vlm_label"):
                    reid.target_tag = best["vlm_label"]
                else:
                    reid.target_tag = current_target_class
                    if reid_future is None:
                        crop_copy = crop.copy()
                        reid_future = vlm_executor.submit(reid.lock_target, crop_copy)
            locked = True
            status_text = f"Auto-locked {current_target_class} — following"
            print(f"[ENGINE] Auto-locked target ({current_target_class}).")

        # ---- 4. Tracking + re-ID (only when a target is locked) ----
        if locked and tracker is not None and mission_state == MISSION_FOLLOW:
            predicted_xy = tracker.predict()

            match = pick_best_candidate(candidates, predicted_xy, REACQUIRE_SEARCH_RADIUS)
            if match is not None:
                match["is_locked"] = True
                tracker.update(match["center"])
                crop = crop_bbox(frame, match["bbox"])

                # Periodic re-ID check (async so we don't freeze)
                if reid.should_check_now() and crop.size > 0 and reid_future is None:
                    reid.last_check_time = time.time()  # mark as checked immediately
                    crop_copy = crop.copy()
                    reid_future = vlm_executor.submit(reid.verify, crop_copy)
                
                status_text = f"Tracking | {reid_status}" if reid_status else "Tracking (Kalman-updated)"
            else:
                status_text = "Coasting on Kalman (no match)"

            # ---- 5. Decision → drone commands ----
            if tracker.is_lost(MAX_MISSED_FRAMES):
                drone.search_pattern()
                status_text = "Target lost — searching"
                locked = False
                mission_state = MISSION_SEARCH
            elif tracker.is_stopped():
                drone.hold_position()
                status_text += " | stopped → holding"
            else:
                tx, ty = tracker.get_position()
                vx, vy = tracker.get_velocity()
                aim_x  = tx + vx * 5
                aim_y  = ty + vy * 5
                drone_pos = drone.get_state()["position"]
                drone.move_toward(aim_x - drone_pos[0], aim_y - drone_pos[1])
                if tracker.has_changed_course():
                    status_text += " | course change → adjusting"

        # Non-FOLLOW mission states — drone controller already set; just advance physics
        drone.step_physics()

        # ---- 6. Draw overlay ----
        _draw_overlay(frame, candidates, tracker, locked, drone, status_text, reid_status, mission_state, cam_source)

        cv2.imshow("Drone Tracking Engine", frame)

        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break

        elif key == ord('l') and candidates:
            # Lock onto the highest-confidence candidate
            best = max(candidates, key=lambda c: c["conf"])
            tracker = KalmanTrack(initial_xy=best["center"], dt=1 / 15.0)
            crop    = crop_bbox(frame, best["bbox"])
            if crop.size > 0:
                # Prefer VLM-enriched label if already classified; else generate in background
                if best["vlm_label"]:
                    reid.target_tag = best["vlm_label"]
                    print(f"[ENGINE] Locked with existing VLM label: '{reid.target_tag}'")
                else:
                    reid.target_tag = current_target_class
                    if reid_future is None:
                        crop_copy = crop.copy()
                        reid_future = vlm_executor.submit(reid.lock_target, crop_copy)
            locked        = True
            mission_state = MISSION_FOLLOW
            status_text   = f"Target locked ({current_target_class}) — following"
            print("[ENGINE] Target locked.")

        elif key == ord('u'):
            locked        = False
            tracker       = None
            reid.target_tag = None
            mission_state = MISSION_HOVER
            drone.hold_position()
            status_text   = "[KEY] Target unlocked — hovering"
            print("[ENGINE] Target unlocked.")

        elif key == ord('h'):
            drone.hold_position()
            mission_state = MISSION_HOVER
            status_text   = "[KEY] Hovering"

        elif key == ord('s'):
            drone.search_pattern()
            locked        = False
            mission_state = MISSION_SEARCH
            status_text   = "[KEY] Searching"

        elif key == ord('r'):
            drone.return_to_launch()
            mission_state = MISSION_RTL
            status_text   = "[KEY] Returning to launch"

    cap.release()
    cv2.destroyAllWindows()


def _draw_overlay(frame, candidates, tracker, locked, drone, status_text, reid_status, mission, cam_source=0):
    """Render all bounding boxes, labels, tracker ring, drone dot, and HUD text."""
    h, w = frame.shape[:2]

    # Draw all detected boxes
    for c in candidates:
        x1, y1, x2, y2 = [int(v) for v in c["bbox"]]
        if c.get("is_locked"):
            box_color = (0, 0, 255)  # Bright Red for locked target
            thickness = 2
        elif c["vlm_label"]:
            box_color = (80, 80, 220)
            thickness = 1
        else:
            box_color = (130, 130, 130)
            thickness = 1

        cv2.rectangle(frame, (x1, y1), (x2, y2), box_color, thickness)

        # Show VLM label if available, otherwise conf score
        label_prefix = "[LOCKED] " if c.get("is_locked") else ""
        label_str = f"{label_prefix}{c['vlm_label']}" if c["vlm_label"] else f"{label_prefix}{c['conf']:.2f}"
        cv2.putText(frame, label_str, (x1, max(y1 - 4, 12)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.38, box_color, thickness)

    # Tracker ring around estimated target position
    if locked and tracker is not None:
        tx, ty = tracker.get_position()
        cv2.circle(frame, (int(tx), int(ty)), 12, (0, 220, 80), 2)
        cv2.circle(frame, (int(tx), int(ty)),  4, (0, 220, 80), -1)

    # Drone dot
    state = drone.get_state()
    if state["position"]:
        dx, dy = state["position"]
        cv2.circle(frame, (int(dx), int(dy)), 7, (255, 140, 0), -1)
        cv2.circle(frame, (int(dx), int(dy)), 7, (255, 200, 0), 1)

    # HUD text (black shadow + white)
    def _text(txt, y, color=(255, 255, 255)):
        cv2.putText(frame, txt, (9,  y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 2)
        cv2.putText(frame, txt, (10, y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color,     1)

    mission_color = {
        "follow": (80, 220, 80), "hover": (220, 200, 60),
        "search": (220, 100, 60), "scan": (60, 180, 220), "rtl": (220, 80, 80),
    }.get(mission, (200, 200, 200))

    cam_str = f"IP: {cam_source}" if isinstance(cam_source, str) else f"Laptop ({cam_source})"

    _text(status_text[:72], 22)
    _text(f"Mission: {mission.upper()}  |  Drone: {state['status']}  |  {cam_str}", 44, mission_color)
    if reid_status:
        _text(reid_status, 66, (180, 220, 255))

    # Key legend bottom-right
    legend = "[q]quit [l]lock [u]unlock [h]hover [s]search [r]rtl"
    cv2.putText(frame, legend, (8, h - 8),
                cv2.FONT_HERSHEY_SIMPLEX, 0.35, (160, 160, 160), 1)


if __name__ == "__main__":
    main()
