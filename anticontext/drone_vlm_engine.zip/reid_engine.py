"""
reid_engine.py
===============
Periodic re-identification layer using SmolVLM-256M-Instruct, inspired by
the Pedestrian Semantic Token Generation (PSTG) idea: instead of a long
description, we prompt the model to distill the target's appearance into a
short semantic tag (a "<REID> ... </REID>" token) and compare tags with a
lightweight text-similarity check.

HONEST LIMITATION (worth knowing before you rely on this): a text-tag
comparison is fuzzier than a real embedding-based re-ID (e.g. cosine
similarity over a CLIP embedding). It's what the PSTG-style prompt gives us
without adding another model, and it's fine for "is this still probably the
same target" at a coarse level - but if re-ID accuracy matters a lot, a
small CLIP-style embedding model is the natural upgrade (see note at the
bottom of this file).

This is called PERIODICALLY (every REID_INTERVAL_SEC), not every frame -
SmolVLM is far too slow (~10s/call on a Pi, per your benchmark) for
per-frame use.

Shared-model support (Phase 5/6 addition):
  Pass shared_model and shared_processor to __init__ to reuse an already-loaded
  SmolVLM instance from SmolObjectClassifier or CommandParser. This saves ~987 MB
  of RAM and avoids a second multi-second model load on startup.
"""

import re
import time

import torch
from PIL import Image
from transformers import AutoProcessor

try:
    from transformers import AutoModelForImageTextToText as AutoVLMModel
except ImportError:
    from transformers import AutoModelForVision2Seq as AutoVLMModel


MODEL_ID = "HuggingFaceTB/SmolVLM-256M-Instruct"  # <-- CHANGE VLM MODEL HERE

# PSTG-style prompt: ask for ONE compact tag, not a paragraph.
REID_PROMPT = (
    "Summarize this person's appearance as a single compact tag inside "
    "<REID></REID>. Include clothing color, clothing type, and any "
    "distinctive item, in 5 words or fewer. "
    "Example: <REID>red jacket, blue jeans, backpack</REID>"
)  # <-- CHANGE REID PROMPT HERE

REID_INTERVAL_SEC = 8.0  # <-- CHANGE how often re-ID checks run (seconds)
SIMILARITY_THRESHOLD = 0.4  # <-- CHANGE re-ID match strictness (0-1, higher = stricter)


def _extract_reid_tag(raw_text):
    """Pull out the <REID>...</REID> content; fall back to the raw text."""
    match = re.search(r"<reid>(.*?)</reid>", raw_text, re.IGNORECASE | re.DOTALL)
    if match:
        return match.group(1).strip().lower()
    return raw_text.strip().lower()


def _token_similarity(tag_a, tag_b):
    """
    Simple word-overlap (Jaccard) similarity between two tags.
    Cheap and dependency-free; swap for embedding cosine similarity if you
    need something more robust (see module docstring).
    """
    words_a = set(re.findall(r"\w+", tag_a))
    words_b = set(re.findall(r"\w+", tag_b))
    if not words_a or not words_b:
        return 0.0
    return len(words_a & words_b) / len(words_a | words_b)


class ReIDEngine:
    def __init__(self, model_id=MODEL_ID, shared_model=None, shared_processor=None):
        """
        Parameters
        ----------
        model_id          : HuggingFace model ID to load (if not using shared instance)
        shared_model      : pre-loaded AutoVLMModel — pass this to skip a second model load
        shared_processor  : pre-loaded AutoProcessor — must be provided with shared_model
        """
        if shared_model is not None and shared_processor is not None:
            print("[REID] Using shared SmolVLM model instance (no second load).")
            self.model = shared_model
            self.processor = shared_processor
            self.device = next(shared_model.parameters()).device
        else:
            print(f"[REID] Loading {model_id} ...")
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
            self.processor = AutoProcessor.from_pretrained(model_id)
            self.model = AutoVLMModel.from_pretrained(
                model_id, torch_dtype=torch.float32
            ).to(self.device)
            self.model.eval()
            print(f"[REID] Loaded on {self.device}.")

        self.target_tag = None       # the stored "who we're tracking" descriptor
        self.last_check_time = 0.0

    def generate_tag(self, cropped_frame_bgr):
        """Run SmolVLM on a cropped target image, return a compact re-ID tag."""
        import cv2
        rgb = cv2.cvtColor(cropped_frame_bgr, cv2.COLOR_BGR2RGB)
        image = Image.fromarray(rgb)

        messages = [{"role": "user", "content": [{"type": "image"}, {"type": "text", "text": REID_PROMPT}]}]
        prompt = self.processor.apply_chat_template(messages, add_generation_prompt=True)
        inputs = self.processor(text=prompt, images=[image], return_tensors="pt").to(self.device)

        with torch.no_grad():
            generated_ids = self.model.generate(
                **inputs, max_new_tokens=25, do_sample=True, temperature=0.2, top_p=0.9
            )

        new_ids = generated_ids[0][inputs["input_ids"].shape[1]:]
        decoded = self.processor.decode(new_ids, skip_special_tokens=True)
        answer = decoded.lower()
        if "assistant" in answer:
            answer = answer.split("assistant")[-1]

        return _extract_reid_tag(answer)

    def lock_target(self, cropped_frame_bgr):
        """Call once, when the target is first acquired, to set the reference tag."""
        self.target_tag = self.generate_tag(cropped_frame_bgr)
        print(f"[REID] Target locked with tag: '{self.target_tag}'")
        return self.target_tag

    def should_check_now(self):
        return (time.time() - self.last_check_time) >= REID_INTERVAL_SEC

    def verify(self, cropped_frame_bgr):
        """
        Periodic check: does the current crop still match the locked target?
        Returns (is_match: bool, similarity: float, new_tag: str)
        """
        self.last_check_time = time.time()

        if self.target_tag is None:
            return True, 1.0, None  # nothing locked yet, nothing to verify against

        candidate_tag = self.generate_tag(cropped_frame_bgr)
        similarity = _token_similarity(self.target_tag, candidate_tag)
        is_match = similarity >= SIMILARITY_THRESHOLD

        print(f"[REID] target='{self.target_tag}' candidate='{candidate_tag}' "
              f"sim={similarity:.2f} match={is_match}")

        return is_match, similarity, candidate_tag


# ------------------------------------------------------------------
# UPGRADE PATH (not implemented here, but worth knowing about):
# For more reliable re-ID than text-tag matching, replace generate_tag's
# output with a real embedding from a small vision model (e.g. a
# MobileCLIP or similar lightweight CLIP variant), and compare embeddings
# with cosine similarity instead of word overlap. This is faster AND more
# accurate than text-based matching - the PSTG "single token" idea maps
# naturally onto "single embedding vector" if you want to go that route.
# ------------------------------------------------------------------
