"""
_bench_diagnostic.py
=====================
Steps 2-4 from the FPS diagnostic specification.
Run BEFORE fixing anything — the goal is to measure, not guess.

Usage:
    # Step 2a: full pipeline, VLM submissions disabled
    python _bench_diagnostic.py --mode a --cam 0

    # Step 2b: mode a + no imshow/waitKey (isolates GUI drag)
    python _bench_diagnostic.py --mode b --cam 0

    # Step 2c: mode a with IP webcam (compare capture latency)
    python _bench_diagnostic.py --mode c --cam http://192.168.0.253:8080/video

    # Step 3: torch thread count delta test (run twice: --threads 2 then --threads 4)
    python _bench_diagnostic.py --mode a --cam 0 --threads 2
    python _bench_diagnostic.py --mode a --cam 0 --threads 4

    # Step 4: just check backend + buffer (no loop, exits immediately)
    python _bench_diagnostic.py --mode backend --cam 0

All modes run for --duration seconds (default 30) then print a summary report.
"""

import argparse
import collections
import csv
import io
import sys
import time
import os

import cv2
import numpy as np
import torch

# ---- parse args first, before any heavy imports ----
ap = argparse.ArgumentParser(description="Drone FPS Diagnostic")
ap.add_argument("--mode",     choices=["a", "b", "c", "backend"], default="a",
                help="a=full-no-VLM, b=no-imshow, c=cam-compare, backend=check only")
ap.add_argument("--cam",      type=str, default="0",
                help="Camera source: integer index or IP URL")
ap.add_argument("--duration", type=int, default=30,
                help="Benchmark duration in seconds (default 30)")
ap.add_argument("--threads",  type=int, default=None,
                help="torch.set_num_threads(N). Default: keep current setting.")
args = ap.parse_args()

# Step 3: set thread count before torch does anything else
if args.threads is not None:
    torch.set_num_threads(args.threads)
    print(f"[BENCH] torch.set_num_threads({args.threads})")
else:
    print(f"[BENCH] torch threads not overridden "
          f"(current = {torch.get_num_threads()})")

# Resolve camera source
cam_source: any = args.cam
if cam_source.isdigit():
    cam_source = int(cam_source)
else:
    if not cam_source.startswith(("http://", "https://", "rtsp://")):
        cam_source = f"http://{cam_source}"
    if not any(cam_source.endswith(ext) for ext in ["/video", ".mjpg", ".mp4", "/mjpeg"]):
        cam_source = cam_source.rstrip("/") + "/video"

# ============================================================
# Minimal PerfTimer (no threading module needed in bench)
# ============================================================

class PerfTimer:
    WINDOW = 60

    def __init__(self, name):
        self.name = name
        self._samples = collections.deque(maxlen=self.WINDOW)
        self._t0 = 0.0

    def start(self):
        self._t0 = time.perf_counter()

    def stop(self):
        self._samples.append((time.perf_counter() - self._t0) * 1000.0)

    def record(self, ms):
        self._samples.append(ms)

    def avg_ms(self):
        s = list(self._samples)
        return sum(s) / len(s) if s else 0.0

    def max_ms(self):
        s = list(self._samples)
        return max(s) if s else 0.0

    def p95_ms(self):
        s = sorted(self._samples)
        return s[int(len(s) * 0.95)] if s else 0.0

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *_):
        self.stop()


# ============================================================
# Step 4: Backend + buffer check
# ============================================================

def check_backend(cam_source):
    print(f"\n[STEP 4] Checking backend for cam_source={cam_source!r}")
    cap = cv2.VideoCapture(cam_source)
    if not cap.isOpened():
        print(f"[STEP 4] ERROR: Could not open camera source.")
        return

    # Set + read back BUFFERSIZE
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    buf_readback = cap.get(cv2.CAP_PROP_BUFFERSIZE)
    try:
        backend = cap.getBackendName()
    except AttributeError:
        backend = f"unknown (OpenCV {cv2.__version__} too old for getBackendName)"

    print(f"  Backend name    : {backend}")
    print(f"  CAP_PROP_BUFFERSIZE requested=1, read-back={buf_readback}  "
          f"({'HONORED' if buf_readback == 1.0 else 'IGNORED — backend silently dropped it'})")
    print(f"  OpenCV version  : {cv2.__version__}")
    print(f"  torch threads   : {torch.get_num_threads()}")

    # Step 4: 10-second frame-gap monitoring
    print(f"\n[STEP 4] Monitoring frame-arrival gaps for 10s to detect buffer backlog...")
    gaps = []
    t_prev = None
    deadline = time.time() + 10.0
    while time.time() < deadline:
        t0 = time.perf_counter()
        ret, _ = cap.read()
        dt = (time.perf_counter() - t0) * 1000.0
        if ret:
            now = time.time()
            if t_prev is not None:
                gaps.append((now - t_prev) * 1000.0)
            t_prev = now

    if gaps:
        mean_gap = sum(gaps) / len(gaps)
        max_gap  = max(gaps)
        min_gap  = min(gaps)
        native_fps = 1000.0 / mean_gap if mean_gap > 0 else 0
        print(f"  Frame gaps: mean={mean_gap:.1f}ms  min={min_gap:.1f}ms  max={max_gap:.1f}ms")
        print(f"  Implied capture FPS: {native_fps:.1f}")
        if max_gap > 3 * mean_gap:
            print(f"  [WARNING] max gap {max_gap:.0f}ms is >3x mean — buffer backlog likely")
        else:
            print(f"  [OK] Gap variance is low — no obvious buffer backlog")
    else:
        print("  [ERROR] No frames received.")
    cap.release()


# ============================================================
# Steps 2a/2b/2c: Isolated benchmark loop
# ============================================================

def run_bench(cam_source, mode: str, duration_sec: int):
    """
    mode 'a': full pipeline (YOLO + Kalman + draw), VLM submissions disabled
    mode 'b': mode a but cv2.imshow/waitKey skipped (count frames to console instead)
    mode 'c': mode a — used to compare cam sources (just run twice with different --cam)
    """
    # ---- Load YOLO only (no VLM, no SmolVLM) ----
    print(f"\n[BENCH mode={mode}] Loading YOLOv8n...")
    sys.path.insert(0, os.path.dirname(__file__))
    from ultralytics import YOLO
    from kalman_tracker import KalmanTrack
    from drone_controller import Sim2DDroneController

    yolo_path = os.path.join(os.path.dirname(__file__), "..", "yolov8n.pt")
    yolo_model = YOLO(yolo_path)

    # ---- Camera ----
    print(f"[BENCH] Opening camera: {cam_source!r}")
    import threading

    class _ThreadedCam:
        """Minimal threaded camera matching ThreadedCameraStream interface."""
        def __init__(self, src):
            self.cap = cv2.VideoCapture(src)
            if isinstance(src, int):
                self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
                self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
            self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
            buf_rb = self.cap.get(cv2.CAP_PROP_BUFFERSIZE)
            try:
                backend = self.cap.getBackendName()
            except AttributeError:
                backend = "unknown"
            print(f"  [CAM] Backend={backend}  BUFFERSIZE read-back={buf_rb}")
            self.latest = None
            self.grabbed = False
            self.stopped = False
            self.lock = threading.Lock()
            self.t_thread = PerfTimer("bg_thread")
            self._gaps = collections.deque(maxlen=60)
            self._t_prev = 0.0
            self.t_copy = PerfTimer("copy")
            th = threading.Thread(target=self._loop, daemon=True)
            th.start()

        def _loop(self):
            while not self.stopped:
                if not self.cap.isOpened():
                    time.sleep(0.01)
                    continue
                t0 = time.perf_counter()
                ok, frame = self.cap.read()
                if ok and frame is not None and frame.size > 0:
                    if (frame.shape[1], frame.shape[0]) != (640, 480):
                        frame = cv2.resize(frame, (640, 480))
                    self.t_thread.record((time.perf_counter() - t0) * 1000.0)
                    now = time.time()
                    if self._t_prev > 0:
                        self._gaps.append(now - self._t_prev)
                    self._t_prev = now
                    with self.lock:
                        self.latest = frame
                        self.grabbed = True
                else:
                    time.sleep(0.01)

        def read(self):
            with self.lock:
                if self.latest is None:
                    return False, None
                t0 = time.perf_counter()
                frame = self.latest.copy()
                self.t_copy.record((time.perf_counter() - t0) * 1000.0)
                return self.grabbed, frame

        def isOpened(self):
            return self.cap.isOpened()

        def release(self):
            self.stopped = True
            self.cap.release()

        def gap_stats(self):
            g = list(self._gaps)
            if not g:
                return 0.0, 0.0
            return (sum(g) / len(g)) * 1000.0, max(g) * 1000.0

    cap = _ThreadedCam(cam_source)
    time.sleep(0.5)  # let bg thread warm up
    if not cap.isOpened():
        print("[BENCH] ERROR: Camera failed to open.")
        return

    drone  = Sim2DDroneController(world_size=(640, 480))
    tracker = None
    candidates = []
    frame_count = 0
    last_known_bbox = None

    # Timers
    t_loop     = PerfTimer("loop")
    t_cam_read = PerfTimer("cam_read")
    t_yolo     = PerfTimer("yolo")
    t_kf       = PerfTimer("kalman")
    t_ovl      = PerfTimer("overlay")
    t_imshow   = PerfTimer("imshow")

    # FPS tracking
    fps_samples = collections.deque(maxlen=60)
    last_fps_print = time.time()
    deadline = time.time() + duration_sec

    DETECT_SKIP = 3   # match locked skip rate for representative test

    if mode in ("a", "b", "c"):
        print(f"[BENCH mode={mode}] Running for {duration_sec}s  "
              f"({'NO imshow' if mode == 'b' else 'WITH imshow'})\n"
              f"  VLM submissions: DISABLED (Step 2 isolation)\n"
              f"  torch threads:   {torch.get_num_threads()}")

    while time.time() < deadline:
        t_loop.start()

        with t_cam_read:
            ret, frame = cap.read()
        if not ret or frame is None:
            time.sleep(0.005)
            continue
        frame_count += 1

        # YOLO every DETECT_SKIP frames (simulate locked state)
        with t_yolo:
            if frame_count % DETECT_SKIP == 0:
                results = yolo_model.predict(source=frame, verbose=False, conf=0.4)
                r = results[0]
                if r.boxes is not None:
                    names = yolo_model.model.names
                    candidates = []
                    for box in r.boxes:
                        cls_id = int(box.cls[0])
                        label  = names.get(cls_id, str(cls_id))
                        if label != "person":
                            continue
                        x1, y1, x2, y2 = box.xyxy[0].tolist()
                        candidates.append({
                            "bbox":   (x1, y1, x2, y2),
                            "conf":   float(box.conf[0]),
                            "center": ((x1+x2)/2, (y1+y2)/2),
                        })

        # Kalman
        with t_kf:
            if candidates:
                best = max(candidates, key=lambda c: c["conf"])
                if tracker is None:
                    tracker = KalmanTrack(initial_xy=best["center"], dt=1/15.0)
                pred = tracker.predict()
                tracker.update(best["center"])

        # Overlay draw
        with t_ovl:
            for c in candidates:
                x1, y1, x2, y2 = [int(v) for v in c["bbox"]]
                cv2.rectangle(frame, (x1, y1), (x2, y2), (130, 130, 130), 1)
            if tracker:
                tx, ty = tracker.get_position()
                cv2.circle(frame, (int(tx), int(ty)), 12, (0, 220, 80), 2)
            cv2.putText(frame, f"mode={mode} threads={torch.get_num_threads()} "
                              f"f={frame_count}", (8, 22),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)

        # imshow — skipped in mode b
        with t_imshow:
            if mode != "b":
                cv2.imshow(f"BENCH mode={mode}", frame)
                key = cv2.waitKey(1) & 0xFF
                if key == ord('q'):
                    break
            else:
                if frame_count % 30 == 0:
                    print(f"  [mode b] frame={frame_count} "
                          f"loop={t_loop.avg_ms():.1f}ms")

        t_loop.stop()
        fps_samples.append(1000.0 / max(t_loop.avg_ms(), 0.1))

        # Console FPS report every 5s
        now = time.time()
        if now - last_fps_print >= 5.0:
            bg_mean, bg_max = cap.gap_stats()
            print(f"  [5s report] "
                  f"loop:{t_loop.avg_ms():.1f}ms ({1000/max(t_loop.avg_ms(),0.1):.1f}fps)  "
                  f"cam_read:{t_cam_read.avg_ms():.1f}ms  "
                  f"copy:{cap.t_copy.avg_ms():.2f}ms  "
                  f"yolo:{t_yolo.avg_ms():.1f}ms  "
                  f"kf:{t_kf.avg_ms():.2f}ms  "
                  f"ovl:{t_ovl.avg_ms():.1f}ms  "
                  f"imshow:{t_imshow.avg_ms():.1f}ms  "
                  f"bg_thread:{cap.t_thread.avg_ms():.1f}ms  "
                  f"bg_gap_mean:{bg_mean:.1f}ms bg_gap_max:{bg_max:.1f}ms")
            last_fps_print = now

    cap.release()
    if mode != "b":
        cv2.destroyAllWindows()

    # ---- Final report ----
    fps_list = list(fps_samples)
    mean_fps = sum(fps_list) / len(fps_list) if fps_list else 0
    bg_mean, bg_max = cap.gap_stats()

    print(f"\n{'='*60}")
    print(f"BENCH SUMMARY  mode={mode}  cam={cam_source!r}")
    print(f"{'='*60}")
    print(f"  Frames processed : {frame_count}")
    print(f"  Duration         : {duration_sec}s")
    print(f"  torch threads    : {torch.get_num_threads()}")
    print(f"")
    print(f"  STAGE TIMING (rolling avg over last {PerfTimer.WINDOW} frames):")
    print(f"  {'Stage':<18} {'avg_ms':>8} {'max_ms':>8} {'p95_ms':>8}")
    print(f"  {'-'*46}")
    for t, label in [
        (t_loop,     "loop (full)"),
        (t_cam_read, "cam_read"),
        (cap.t_copy, "copy"),
        (t_yolo,     "yolo"),
        (t_kf,       "kalman"),
        (t_ovl,      "overlay"),
        (t_imshow,   "imshow+waitKey"),
        (cap.t_thread,"bg_thread_read"),
    ]:
        print(f"  {label:<18} {t.avg_ms():>8.2f} {t.max_ms():>8.2f} {t.p95_ms():>8.2f}")
    print(f"")
    print(f"  bg_gap mean: {bg_mean:.1f}ms  max: {bg_max:.1f}ms")
    print(f"  Main loop FPS:  mean={mean_fps:.1f}")
    print(f"  Implied ceiling (no imshow): "
          f"{1000/max(t_loop.avg_ms()-t_imshow.avg_ms(),0.1):.1f}fps")
    print(f"{'='*60}")

    # ---- Hypothesis guidance ----
    print(f"\nHYPOTHESIS POINTERS:")
    loop_no_imshow = t_loop.avg_ms() - t_imshow.avg_ms()
    if t_imshow.avg_ms() > 0.4 * t_loop.avg_ms():
        print(f"  -> imshow+waitKey is {t_imshow.avg_ms()/t_loop.avg_ms()*100:.0f}% of loop time")
        print(f"     HYPOTHESIS: GUI rendering is the bottleneck (test mode b vs a delta)")
    if t_yolo.avg_ms() > 0.4 * t_loop.avg_ms():
        print(f"  -> YOLO is {t_yolo.avg_ms()/t_loop.avg_ms()*100:.0f}% of loop time")
        print(f"     HYPOTHESIS: Inference speed — check torch thread count (--threads 4)")
    if t_cam_read.avg_ms() > 10.0:
        print(f"  -> cam_read (main thread) = {t_cam_read.avg_ms():.1f}ms")
        print(f"     HYPOTHESIS: Main thread is blocking on camera lock or copy overhead")
    if bg_max > 3 * bg_mean and bg_mean > 0:
        print(f"  -> bg_gap max ({bg_max:.0f}ms) >> mean ({bg_mean:.0f}ms)")
        print(f"     HYPOTHESIS: Camera network/buffer backlog (IP webcam issue)")
    if cap.t_thread.avg_ms() > 80.0:
        print(f"  -> bg_thread_read = {cap.t_thread.avg_ms():.1f}ms/frame")
        print(f"     HYPOTHESIS: Network decode latency (IP webcam) or USB bandwidth limit")
    print()


# ============================================================
# Entry point
# ============================================================

if args.mode == "backend":
    check_backend(cam_source)
else:
    run_bench(cam_source, args.mode, args.duration)
