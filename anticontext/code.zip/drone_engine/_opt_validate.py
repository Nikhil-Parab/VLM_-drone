"""Quick validation of optimization changes (no GPU/model needed)."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "drone_engine"))

import numpy as np
import cv2

# ---- Phase C: embedding helpers (import first so set_num_threads fires) ----
import reid_engine

import torch

# ---- Phase B: torch threads capped ----
print(f"[B] torch.get_num_threads() = {torch.get_num_threads()}  (expected 2)")
assert torch.get_num_threads() == 2, "Thread count should be 2 after reid_engine import"

fake_crop_a = np.random.randint(0, 255, (128, 64, 3), dtype=np.uint8)
fake_crop_b = np.random.randint(0, 255, (128, 64, 3), dtype=np.uint8)

emb_a = reid_engine._compute_embedding(fake_crop_a)
emb_b = reid_engine._compute_embedding(fake_crop_b)
assert emb_a is not None, "embedding A should not be None"
assert emb_b is not None, "embedding B should not be None"

self_sim = reid_engine._embedding_similarity(emb_a, emb_a)
cross_sim = reid_engine._embedding_similarity(emb_a, emb_b)
print(f"[C] Self-similarity:  {self_sim:.3f}  (should be ~1.0)")
print(f"[C] Cross-similarity: {cross_sim:.3f}  (should be < self)")
assert self_sim > 0.9, f"Self-similarity too low: {self_sim}"

# REID_INTERVAL_SEC dropped
print(f"[C] REID_INTERVAL_SEC = {reid_engine.REID_INTERVAL_SEC}  (expected 0.5)")
assert reid_engine.REID_INTERVAL_SEC == 0.5

# ---- Phase H: fuzzy COCO match ----
from voice_command_interface import _fuzzy_coco_match, _normalise_coco, CONFIRM_BEFORE_EXECUTE

key, dist = _fuzzy_coco_match("phne", threshold=4)  # 'phne' is 1 edit from 'phone'
print(f"[H] fuzzy('phne') -> key='{key}' dist={dist}")
assert key in ("phone", "mobile phone", "cell phone", "smartphone"), f"Unexpected key: '{key}'"

result = _normalise_coco("phne")
print(f"[H] _normalise_coco('phne') = '{result}' (expected 'cell phone')")
assert result == "cell phone", f"Expected 'cell phone', got '{result}'"

print(f"[H] CONFIRM_BEFORE_EXECUTE = {CONFIRM_BEFORE_EXECUTE}")
assert "rtl" in CONFIRM_BEFORE_EXECUTE
assert "land" in CONFIRM_BEFORE_EXECUTE

# ---- Phase D: ROI helpers exist ----
from drone_tracking_engine import detect_in_roi, DETECT_EVERY_N_FRAMES_LOCKED, ROI_PAD_PX
print(f"[D] DETECT_EVERY_N_FRAMES_LOCKED = {DETECT_EVERY_N_FRAMES_LOCKED}")
print(f"[D] ROI_PAD_PX = {ROI_PAD_PX}")

# ---- Phase G: _iou helper ----
from drone_tracking_engine import _iou, pick_best_candidate
iou_self = _iou((10, 10, 50, 50), (10, 10, 50, 50))
iou_none = _iou((0, 0, 10, 10), (100, 100, 200, 200))
print(f"[G] IoU self-overlap: {iou_self:.3f}  (expected 1.0)")
print(f"[G] IoU no-overlap:   {iou_none:.3f}  (expected 0.0)")
assert iou_self > 0.99
assert iou_none == 0.0

# ---- Phase I: PerfTimer ----
from drone_tracking_engine import PerfTimer
timer = PerfTimer("test")
import time
with timer:
    time.sleep(0.005)
print(f"[I] PerfTimer avg_ms ≈ {timer.avg_ms():.1f}ms  (expected ~5)")
assert timer.avg_ms() > 1.0

print()
print("=" * 50)
print("ALL OPTIMIZATION CHECKS PASSED.")
print("=" * 50)
